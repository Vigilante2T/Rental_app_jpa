package com.cg.rentalapp.dto;

import java.math.BigInteger;

public class Property {
	//defining all variables
	private String area;
	private long pincode;
	private String buildingName;
	private int flatNumber;
	private BigInteger referredBy;
	private int commission;
	private String flatType;
	private Advertisement ads; 
	//creating a non parameterized constructor
	public Property() {
		// TODO Auto-generated constructor stub
	}
	//creating parameterized constructor
	public Property(String area, long pincode, String buildingName, int flatNumber, BigInteger referredBy,
			int commission, String flatType, Advertisement ads) {
		super();
		this.area = area;
		this.pincode = pincode;
		this.buildingName = buildingName;
		this.flatNumber = flatNumber;
		this.referredBy = referredBy;
		this.commission = commission;
		this.flatType = flatType;
		this.ads = ads;
	}

	// generating getters and setters for all variables respectively
	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public long getPincode() {
		return pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public int getFlatNumber() {
		return flatNumber;
	}

	public void setFlatNumber(int flatNumber) {
		this.flatNumber = flatNumber;
	}

	public BigInteger getReferredBy() {
		return referredBy;
	}

	public void setReferredBy(BigInteger referredBy) {
		this.referredBy = referredBy;
	}

	public int getCommission() {
		return commission;
	}

	public void setCommission(int commission) {
		this.commission = commission;
	}

	public String getFlatType() {
		return flatType;
	}

	public void setFlatType(String flatType) {
		this.flatType = flatType;
	}

	public Advertisement getAds() {
		return ads;
	}

	public void setAds(Advertisement ads) {
		this.ads = ads;
	}
	// generating a toString method for all variables 
	@Override
	public String toString() {
		return "Property [area=" + area + ", pincode=" + pincode + ", buildingName=" + buildingName + ", flatNumber="
				+ flatNumber + ", referredBy=" + referredBy + ", commission=" + commission + ", flatType=" + flatType
				+ ", ads=" + ads + "]";
	}
	
	
	

}
