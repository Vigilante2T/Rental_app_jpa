package com.cg.rentalapp.exception;

public class AdvertisementException extends Exception {

	public AdvertisementException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AdvertisementException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public AdvertisementException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AdvertisementException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public AdvertisementException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
