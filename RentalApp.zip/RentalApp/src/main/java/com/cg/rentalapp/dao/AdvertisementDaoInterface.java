package com.cg.rentalapp.dao;

import java.net.ConnectException;
import java.util.List;

import com.cg.rentalapp.dto.Advertisement;
import com.cg.rentalapp.dto.Agent;
import com.cg.rentalapp.dto.Property;

public interface AdvertisementDaoInterface {
	
	public Agent saveAgent(Agent agent) throws Exception;
	public Advertisement saveAdvertisement(Advertisement ads) throws Exception ;
	public Property saveProperty(Property property) throws Exception;
	public List<Advertisement> findByLocation(String area) throws Exception;
	public List<Advertisement> findByPincode(long pincode) throws Exception;

}
