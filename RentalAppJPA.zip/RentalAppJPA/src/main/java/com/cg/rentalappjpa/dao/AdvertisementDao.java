package com.cg.rentalappjpa.dao;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.rentalappjpa.dbutil.DbUtil;
import com.cg.rentalappjpa.dto.Advertisement;
import com.cg.rentalappjpa.dto.Agent;
import com.cg.rentalappjpa.dto.Property;

public class AdvertisementDao implements AdvertisementDaoInterface {
	
	static List<Advertisement> advertisements=new ArrayList<Advertisement>(); //creating object for Advertisement list
	static List<Agent> agents=new ArrayList<Agent>(); //creating object for Agent list
	static List<Property> properties = new ArrayList<Property>(); //creating object for Property list
	 
	EntityManager em; // defining entityManger variable
	
	
	
	public AdvertisementDao() {
		// TODO Auto-generated constructor stub
		em = DbUtil.getConnection();//for connection with database
		
	}

	public Agent saveAgent(Agent agent) throws Exception { //for saving agent in database
		try {
			em = DbUtil.getConnection();//for connection with database
			em.persist(agent); //for persisting the data to agent 
			em.getTransaction().commit(); //commmiting the data into database
			
		}catch(Exception e){ // handling the exception
			throw new Exception("Enter the credentials properly");
		}finally { //closing the connection
			em.close();
		}
		return agent;
	}
	
	public Advertisement saveAdvertisement(Advertisement ads) throws Exception{ //for saving Advertisement in database
		try {
			em = DbUtil.getConnection();//for connection with database
			em.persist(ads); //for persisting the data to Advertisement 
			em.getTransaction().commit(); //commmiting the data into database
			
		}catch(Exception e){ // handling the exception
			throw new Exception("First be a registered agent");
		}finally {
			em.close(); //closing the connection
		}
		return ads;
	}
	
	public Property saveProperty(Property property) throws Exception { //for saving Property in database
		// TODO Auto-generated method stub
		try {
			em = DbUtil.getConnection(); //for connection with database
			em.persist(property); //for persisting the data to Property
			em.getTransaction().commit(); //commmiting the data into database
			
		}catch(Exception e){// handling the exception
			throw new Exception("First be a registered agent");
		}finally {
			em.close();//closing the connection
		}
		return property;
	}
	
	public List<Advertisement> findByLocation(String area) throws Exception {
		try {
			List<Advertisement> advertisementList = new ArrayList<Advertisement>(); //defining object of list of Advertisement
			em=DbUtil.getConnection(); //for connection with database
			TypedQuery<Advertisement> query = em.createQuery("select ad from Advertisement ad where ad.area=?",Advertisement.class); //query for fetching advertisements of a specific area from table
			query.setParameter(1, area); //setting value of area in runtime
			List<Advertisement> ads = query.getResultList(); //fetching the desired data from database
			return ads;
		}catch(Exception e) { // handling the exception
			throw new Exception("Advertisement not Found in this area");
		}finally {
			em.close(); //closing the connection
		}		
	}
	
	public List<Advertisement> findByPincode(long pincode) throws Exception {
		try {
		List<Advertisement> advertisementList = new ArrayList<Advertisement>(); //defining object of list of Advertisement
		em=DbUtil.getConnection(); //for connection with database
		TypedQuery<Advertisement> query = em.createQuery("select ad from Advertisement ad where ad.pincode=?",Advertisement.class);//query for fetching advertisements of a specific area from table
		query.setParameter(1, pincode); //setting value of area in runtime
		List<Advertisement> ads = query.getResultList(); //fetching the desired data from database
		return ads;
		}catch(Exception e) { // handling the exception
			throw new Exception("Advertisement not Found in this area");
		}finally {
			em.close(); //closing the connection
		}
	}

}
