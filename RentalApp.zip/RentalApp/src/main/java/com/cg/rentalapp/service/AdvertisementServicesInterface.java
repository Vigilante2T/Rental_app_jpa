package com.cg.rentalapp.service;

import java.net.ConnectException;
import java.util.List;

import com.cg.rentalapp.dto.Advertisement;
import com.cg.rentalapp.dto.Agent;
import com.cg.rentalapp.dto.Property;

public interface AdvertisementServicesInterface {
	
	public Agent addAgent(Agent agent) throws Exception;
	public Advertisement addAdvertisement(Advertisement ads) throws Exception;
	public Property addProperty(Property property) throws Exception;
	public List<Advertisement> searchByLocation(String area) throws Exception;
	public List<Advertisement> searchByPincode(long pincode) throws Exception;

}
