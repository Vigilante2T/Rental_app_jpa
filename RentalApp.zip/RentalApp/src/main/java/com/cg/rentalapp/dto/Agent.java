package com.cg.rentalapp.dto;

import java.math.BigInteger;
import java.util.List;

public class Agent {
	//defining all variables
	private BigInteger phoneNumber;
	private String name;
	private List<Advertisement> advertisement;
	//creating a non parameterized constructor
	public Agent() {
		super();
		// TODO Auto-generated constructor stub
	}
	//creating parameterized constructor
	public Agent(BigInteger phoneNumber, String name, List<Advertisement> advertisement) {
		super();
		this.phoneNumber = phoneNumber;
		this.name = name;
		this.advertisement = advertisement;
	}
	// generating getters and setters for all variables respectively
	public BigInteger getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(BigInteger phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Advertisement> getAdvertisement() {
		return advertisement;
	}

	public void setAdvertisement(List<Advertisement> advertisement) {
		this.advertisement = advertisement;
	}
	// generating a toString method for all variables 
	@Override
	public String toString() {
		return "Agent [phoneNumber=" + phoneNumber + ", name=" + name + ", advertisement=" + advertisement + "]";
	}
	
	

}
