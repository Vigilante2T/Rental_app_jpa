package com.cg.rentalappjpa.dto;

import java.math.BigInteger;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="property")
public class Property {
	//defining all variables
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int property_id;
	@Column(name="area")
	private String area;
	@Column(name="pincode")
	private long pincode;
	@Column(name="building_name")
	private String buildingName;
	@Column(name="flat_number")
	private int flatNumber;
	@Column(name="referred_by")
	private BigInteger referredBy;
	@Column(name="commission")
	private int commission;
	@Column(name="flat_type")
	private String flatType;
	
	//creating a non parameterized constructor
	public Property() {
		// TODO Auto-generated constructor stub
	}
	
	//creating parameterized constructor
	public Property( String area, long pincode, String buildingName, int flatNumber,
			BigInteger referredBy, int commission, String flatType) {
		super();
//		this.property_id = property_id;
		this.area = area;
		this.pincode = pincode;
		this.buildingName = buildingName;
		this.flatNumber = flatNumber;
		this.referredBy = referredBy;
		this.commission = commission;
		this.flatType = flatType;
//		this.advertisement = advertisement;
	}

	// generating getters and setters for all variables respectively
//	public int getProperty_id() {
//		return property_id;
//	}
//
//	public void setProperty_id(int property_id) {
//		this.property_id = property_id;
//	}
	
	public String getArea() {
		return area;
	}

	

	public void setArea(String area) {
		this.area = area;
	}

	public long getPincode() {
		return pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public int getFlatNumber() {
		return flatNumber;
	}

	public void setFlatNumber(int flatNumber) {
		this.flatNumber = flatNumber;
	}

	public BigInteger getReferredBy() {
		return referredBy;
	}

	public void setReferredBy(BigInteger referredBy) {
		this.referredBy = referredBy;
	}

	public int getCommission() {
		return commission;
	}

	public void setCommission(int commission) {
		this.commission = commission;
	}

	public String getFlatType() {
		return flatType;
	}

	public void setFlatType(String flatType) {
		this.flatType = flatType;
	}

	
	

//	public Advertisement getAds() {
//		return ads;
//	}
//
//	public void setAds(Advertisement ads) {
//		this.ads = ads;
//	}
//	
//	public int getAdvertisement_id() {
//		return advertisement_id;
//	}
//
//	public void setAdvertisement_id(int advertisement_id) {
//		this.advertisement_id = advertisement_id;
//	}

	// generating a toString method for all variables 
	
	@Override
	public String toString() {
		return "Property [ area=" + area + ", pincode=" + pincode + ", buildingName="
				+ buildingName + ", flatNumber=" + flatNumber + ", referredBy=" + referredBy + ", commission="
				+ commission + ", flatType=" + flatType + "]";
	}

	

}
