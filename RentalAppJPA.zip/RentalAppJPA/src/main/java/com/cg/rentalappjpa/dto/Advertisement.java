package com.cg.rentalappjpa.dto;

import java.math.BigInteger;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="advertisement")
public class Advertisement { 
	//defining all variables
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int advertisement_id;
	@Column(name="area")
	private String area;
	@Column(name="pincode")
	private long pincode;
	@Column(name="phone_number")
	private BigInteger phoneNumber;
	@Column(name="flat_type")
	private String flatType;
	@OneToOne(cascade= CascadeType.ALL)
	@JoinColumn(name="property_id")
	private Property property;
	//creating a non parameterized constructor
	public Advertisement() {
		super();
		// TODO Auto-generated constructor stub
	}
	//creating parameterized constructor
	public Advertisement(String area, long pincode, BigInteger phoneNumber, String flatType, Property property) {
		super();
		this.area = area;
		this.pincode = pincode;
		this.phoneNumber = phoneNumber;
		this.flatType = flatType;
		this.property = property;
	}

	// generating getters and setters for all variables respectively
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public long getPincode() {
		return pincode;
	}
	public void setPincode(long pincode) {
		this.pincode = pincode;
	}
	public BigInteger getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(BigInteger phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getFlatType() {
		return flatType;
	}
	public void setFlatType(String flatType) {
		this.flatType = flatType;
	}
	public Property getProperty() {
		return property;
	}
	public void setProperty(Property property) {
		this.property = property;
	}
	
	// generating a toString method for all variables 
		@Override
		public String toString() {
			return "Advertisement [area=" + area + ", pincode=" + pincode + ", phoneNumber=" + phoneNumber + ", flatType="
					+ flatType + ", property=" + property + "]";
		}

}
