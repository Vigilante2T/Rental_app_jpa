package com.cg.rentalappjpa.dbutil;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DbUtil {
	

static EntityManager em=null; //defining entityManager variable
 public static EntityManager getConnection() { // for connection with database
 EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("rentalappjpa");
 em=entityManagerFactory.createEntityManager();
 em.getTransaction().begin();
 return em;
}

}
