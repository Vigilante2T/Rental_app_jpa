package com.cg.rentalappjpa.dao;

import java.util.List;

import com.cg.rentalappjpa.dto.Advertisement;
import com.cg.rentalappjpa.dto.Agent;
import com.cg.rentalappjpa.dto.Property;



public interface AdvertisementDaoInterface {
	
	public Agent saveAgent(Agent agent) throws Exception;
	public Advertisement saveAdvertisement(Advertisement ads) throws Exception ;
	public Property saveProperty(Property property) throws Exception;
	public List<Advertisement> findByLocation(String area) throws Exception;
	public List<Advertisement> findByPincode(long pincode) throws Exception;


}
