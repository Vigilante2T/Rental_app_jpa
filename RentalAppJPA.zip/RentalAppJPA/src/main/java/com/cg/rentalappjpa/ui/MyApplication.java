package com.cg.rentalappjpa.ui;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.rentalappjpa.dto.Advertisement;
import com.cg.rentalappjpa.dto.Agent;
import com.cg.rentalappjpa.dto.Property;
import com.cg.rentalappjpa.services.AdvertisementServices;



public class MyApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scr = new Scanner(System.in); //For taking input from user 
		int choice;
	    AdvertisementServices adServices = new AdvertisementServices(); //creating service object for saving data
	
	do {
		System.out.println("!--Flat renting or Buying/Selling Platform for Pune--!"); //Display headings
		System.out.println("Services Provided :");
		System.out.println("1. Add Agent");
		System.out.println("2. Add Advertisement");
		System.out.println("3. Search Ads by Area");
		System.out.println("4. Search Ads by Pincode");
		choice = scr.nextInt(); //Taking user input choice from above list
		
		switch(choice) {
		case 1: List<Agent> agents = new ArrayList<Agent>(); //creating object for Agent list
		scr.nextLine();
		System.out.println("Enter your name");
		String name = scr.next();
		System.out.println("Enter your phone number");
		BigInteger phoneNumber = scr.nextBigInteger();
		Agent agent = new Agent(phoneNumber, name,null); //Passing values to Agent using parameters
			try {
				adServices.addAgent(agent);//Adding all values to Agent // Saving Agent in database by passing it to service layer
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			} 
		break;
		
		case 2: List<Advertisement> advertisements = new ArrayList<Advertisement>(); // Creating object for Advertisement list 
		scr.nextLine();
		System.out.println("Enter your area");
		String area = scr.nextLine();
		System.out.println("Enter pincode");
		long pincode = scr.nextLong();
		System.out.println("Enter your phone number");
		BigInteger adPhoneNumber = scr.nextBigInteger();
		System.out.println("Enter Building name");
		String buildingName = scr.next();
		System.out.println("Enter flat number");
		int flatNumber = scr.nextInt();
		System.out.println("Enter flat type");
		String flatType = scr.next();
		System.out.println("Enter commission in percentage");
		int commission = scr.nextInt();
		Property property = new Property( area,pincode,buildingName,flatNumber,adPhoneNumber,commission,flatType);//Passing values to Property using parameters
		Advertisement advertisement = new Advertisement(area,pincode,adPhoneNumber,flatType, property);//Passing values to Advertisement using parameters
			try {
				adServices.addAdvertisement(advertisement);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			} // Saving Property in database by passing it to service layer
			try {
				adServices.addProperty(property);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			} // Saving Advertisement in database by passing it to service layer
		break;
		
		case 3:System.out.println("Enter area to be searched : "); // Searching advertisement in a specific area
		String searchByArea = scr.next();
			List<Advertisement> searchByLocation;
			try {
				searchByLocation = adServices.searchByLocation(searchByArea);
				for(Advertisement ads: searchByLocation) { //using for each loop for iteration
					System.out.print("Area = "+ads.getArea()+" , ");
					System.out.print("Pincode = "+ads.getPincode()+" , ");
					System.out.print("Phone number = " +ads.getPhoneNumber()+" , ");
					System.out.print("Flat type = "+ads.getFlatType()+" . ");
					System.out.println();
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}  // Creating object for Advertisement list and passing value to service layer
		
		break;
		
		case 4: System.out.println("Enter pincode to be searched : ");// Searching advertisement through specific pincode
		long searchByPincode = scr.nextLong();
			List<Advertisement> searchAdsByPincode;
			try {
				searchAdsByPincode = adServices.searchByPincode(searchByPincode);
				for(Advertisement ads: searchAdsByPincode) { //using for each loop for iteration
					System.out.print("Area = "+ads.getArea()+" , ");
					System.out.print("Pincode = "+ads.getPincode()+" , ");
					System.out.print("Phone number = " +ads.getPhoneNumber()+" , ");
					System.out.print("Flat type = "+ads.getFlatType()+" . ");
					System.out.println();
					
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			} // Creating object for Advertisement list and passing value to service layer
		
		break;
		default: System.out.println("Invalid choice entered"); //default Statement for invalid entered choice
		break;
		}
		
	}while(choice!=4);

	}

}
