package com.cg.rentalapp.ui;

import java.math.BigInteger;
import java.net.ConnectException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.rentalapp.dto.Advertisement;
import com.cg.rentalapp.dto.Agent;
import com.cg.rentalapp.dto.Property;
import com.cg.rentalapp.service.AdvertisementServices;
import com.cg.rentalapp.service.AdvertisementServicesInterface;

public class MyApplication {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Scanner scr = new Scanner(System.in); //For taking input from user 
		int choice;
	AdvertisementServices adServices = new AdvertisementServices(); //creating service object for saving data
	
	System.out.println("!--Flat renting or Buying/Selling Platform for Pune--!"); //Display headings
	System.out.println("Services Provided :");
	System.out.println("1. Add Agent");
	System.out.println("2. Add Advertisement");
	System.out.println("3. Search Ads by Area");
	System.out.println("4. Search Ads by Pincode");
	
	
	do {
		choice = scr.nextInt(); //Taking user input choice from above list
		
		switch(choice) {
		case 1: List<Agent> agents = new ArrayList<Agent>(); //creating object for Agent list
		scr.nextLine();
		System.out.println("Enter your name");
		String name = scr.next();
		System.out.println("Enter your phone number");
		BigInteger phoneNumber = scr.nextBigInteger();
		Agent agent = new Agent(phoneNumber, name,null); //Passing values to Agent using parameters
			try {
				adServices.addAgent(agent);//Adding all values to Agent // Saving Agent in database by passing it to service layer
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			} 
		break;
		
		case 2: List<Advertisement> advertisements = new ArrayList<Advertisement>(); // Creating object for Advertisement list 
		scr.nextLine();
		System.out.println("Enter your area");
		String area = scr.nextLine();
		System.out.println("Enter pincode");
		long pincode = scr.nextLong();
		System.out.println("Enter your phone number");
		BigInteger adPhoneNumber = scr.nextBigInteger();
		System.out.println("Enter Building name");
		String buildingName = scr.next();
		System.out.println("Enter flat number");
		int flatNumber = scr.nextInt();
		System.out.println("Enter flat type");
		String flatType = scr.next();
		System.out.println("Enter commission in percentage");
		int commission = scr.nextInt();
		Property property = new Property(area,pincode,buildingName,flatNumber,adPhoneNumber,commission,flatType,null);//Passing values to Property using parameters
		Advertisement advertisement = new Advertisement(area,pincode,adPhoneNumber,flatType,null);//Passing values to Advertisement using parameters
			try {
				adServices.addAdvertisement(advertisement);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			} // Saving Property in database by passing it to service layer
			try {
				adServices.addProperty(property);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			} // Saving Advertisement in database by passing it to service layer
		break;
		
		case 3:System.out.println("Enter area to be searched : "); // Searching advertisement in a specific area
		String searchByArea = scr.next();
			List<Advertisement> searchByLocation;
			try {
				searchByLocation = adServices.searchByLocation(searchByArea);
				for(Advertisement ads: searchByLocation) { //using for each loop for iteration 
					System.out.print("Area = "+ads.getArea()+" , ");
					System.out.print("Pincode = "+ads.getPincode()+" , ");
					System.out.print("Phone number = " +ads.getPhoneNumber()+" , ");
					System.out.print("Flat type = "+ads.getFlatType()+" . ");
					System.out.println();
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}  // Creating object for Advertisement list and passing value to service layer
		
		break;
		
		case 4: System.out.println("Enter pincode to be searched : ");// Searching advertisement through specific pincode
		long searchByPincode = scr.nextLong();
			List<Advertisement> searchAdsByPincode;
			try {
				searchAdsByPincode = adServices.searchByPincode(searchByPincode);
				for(Advertisement ads: searchAdsByPincode) { //using for each loop for iteration 
					System.out.print("Area = "+ads.getArea()+" , ");
					System.out.print("Pincode = "+ads.getPincode()+" , ");
					System.out.print("Phone number = " +ads.getPhoneNumber()+" , ");
					System.out.print("Flat type = "+ads.getFlatType()+" . ");
					System.out.println();
					
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			} // Creating object for Advertisement list and passing value to service layer
		
		break;
		default: System.out.println("Invalid choice entered"); //default Statement for invalid entered choice
		break;
		}
		
	}while(choice!=4);
	
//	System.out.println("Enter your area");
//	String area = scr.next();
//		System.out.println("Enter your pincode");
//		long pincode = scr.nextLong();
//	System.out.println("Enter your phone number");
//	BigInteger phoneNumber = scr.nextBigInteger();
//		System.out.println("Enter Flat type");
//		String flatType = scr.next();
//		System.out.println("Enter building name");
//		String buildingName = scr.next();
//		System.out.println("Enter flat number");
//		int flatNumber = scr.nextInt();
//		System.out.println("Enter commission in percentages");
//		int commission = scr.nextInt();
		
		
		/*List<Advertisement> advertisements = new ArrayList<Advertisement>();
		
		Property propertiesOne = new Property("Wakad",411033,"Omega",504,new BigInteger("8770283985"),25,"3BHK", null);
		Property propertiesTwo = new Property("Tathawade",411033,"Akshar",902,new BigInteger("8815061459"),25,"3BHK", null);

		
		Advertisement advertisementsOne = new Advertisement("Wakad",411033,new BigInteger("8770283985"),"3BHKJ",propertiesOne);
		Advertisement advertisementsTwo = new Advertisement("Tathawade",411033,new BigInteger("8815061459"),"3BHKJ",propertiesTwo);
		advertisements.add(advertisementsOne);
		advertisements.add(advertisementsTwo);

		Agent agent = new Agent(new BigInteger("8770283985"),"Dean",advertisements);
		
		AdvertisementServices advertisementServices = new AdvertisementServices();
		
		
			advertisementServices.addAgent(agent);
			advertisementServices.addAdvertisement(advertisementsOne);
			advertisementServices.addAdvertisement(advertisementsTwo);
		
		
		
		do {
			
//			System.out.println("!-------#Mai_Bhi_Chowkidaar--------!");
			System.out.println("!--Flat renting or Buying/Selling Platform for Pune--!");
			System.out.println("Services Provided :");
//			System.out.println("1. Add Agent");
//			System.out.println("2. Add Advertisement");
			System.out.println("1. Search Ads by Area");
			System.out.println("2. Search Ads by Pincode");
			
			int choice = scr.nextInt();
			switch(choice) {
			case 1: System.out.println("Enter area to be searched in : ");
			String area = scr.next();
			List<Advertisement> searchByLocation = advertisementServices.searchByLocation(area);
			for(Advertisement ads: searchByLocation) {
				if(ads.getArea().equals(area)) {
					System.out.println(ads);
				}
			}
			break;
			case 2: System.out.println("Enter pincode to be searched : ");
			long pincode = scr.nextLong();
			List<Advertisement> searchAdsByPincode = advertisementServices.searchByPincode(pincode);
			for(Advertisement ads: searchAdsByPincode) {
				if(ads.getPincode()==(pincode)) {
					System.out.println(ads);
				}
			}
			break;
			default: System.out.println("Invalid choice entered");
			break;
			}
			
		}while(1!=4);
		*/
		
		
		
//		AdvertisementServices service;
//		
//		service = new AdvertisementServices();
//		
//		Property properties = new Property();
//		Agent agentDetails = new Agent();
//		Advertisement adDetails = new Advertisement();
//		
//		Scanner scr = new Scanner(System.in);
//		properties.setArea("Wakad");
//		properties.setPincode(411033);
//		properties.setBuildingName("Omega");
//		properties.setFlatNumber(504);
//		properties.setPhoneNumber(new BigInteger("877020000"));
//		properties.setCommission(25);
//		properties.setFlatType("3BHK");
//		
//		System.out.println("!-------#Mai_Bhi_Chowkidaar--------!");
//		System.out.println("!--Flat renting or Buying/Selling Platform for Pune--!");
//		
//		int choices =0;
//		
//		do {
//			System.out.println("Services Provided :");
//			System.out.println("1. Add Agent");
//			System.out.println("2. Add Advertisement");
//			System.out.println("3. Search Ads by Area");
//			System.out.println("4. Search Ads by Pincode");
//			
//			 choices = scr.nextInt();
//		}while(choices!=4);
//		
//		System.out.println("Enter area ");
//		String area = scr.next();
//		System.out.println("Enter Pincode of the above area");
//		long pincode = scr.nextLong();
//		System.out.println("Enter buildingName");
//		String buildingName = scr.next();
//		System.out.println("Enter flat number");
//		int flatNumber = scr.nextInt();
//		System.out.println("Enter phone number");
//		BigInteger phoneNumber = scr.nextBigInteger();
//		System.out.println("Enter commission in percentage ");
//		int commission = scr.nextInt();
//		System.out.println("Enter flat type");
//		String flatType = scr.next();
//		
//		properties.setArea(area);
//		properties.setPincode(pincode);
//		properties.setBuildingName(buildingName);
//		properties.setFlatNumber(flatNumber);
//		properties.setPhoneNumber(phoneNumber);
//		properties.setCommission(commission);
//		properties.setFlatType(flatType);
//		
//		
//		System.out.println(properties);

	}

}
