package com.cg.rentalappjpa.services;

import java.util.List;

import com.cg.rentalappjpa.dto.Advertisement;
import com.cg.rentalappjpa.dto.Agent;
import com.cg.rentalappjpa.dto.Property;



public interface AdvertisementServicesInterface {

	public Agent addAgent(Agent agent) throws Exception;
	public Advertisement addAdvertisement(Advertisement ads) throws Exception;
	public Property addProperty(Property property) throws Exception;
	public List<Advertisement> searchByLocation(String area) throws Exception;
	public List<Advertisement> searchByPincode(long pincode) throws Exception;
	
}
