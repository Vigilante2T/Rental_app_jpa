package com.cg.rentalapp.dbutil;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.ConnectException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DbUtil {
	
	static Connection conn;
	
	public static Connection getConnection() throws ConnectException {
		Properties prop = new Properties(); //creating object for Properties class
		InputStream it= null;
		 try {
		  it= new FileInputStream("src/main/resources/jdbc.properties"); //defining path for loading JDBC file
		  prop.load(it); //load file
		  if(prop!=null)
		  {
		   String driver= prop.getProperty("jdbc.driver"); //path of driver
		   String url= prop.getProperty("jdbc.url"); //path of URL
		   String name= prop.getProperty("jdbc.username"); // path of user name
		   String pass= prop.getProperty("jdbc.passward"); // path of password
		   
		   Class.forName(driver); // loading the driver
		   conn=DriverManager.getConnection(url,name,pass); // connecting to database
		  }
		 }
		 catch (FileNotFoundException e) {
		  throw new ConnectException("Connection not established!");
		 }
		 catch (IOException e) {
			 throw new ConnectException("Connection not established!");
		  }
		 catch (ClassNotFoundException e) {
			 throw new ConnectException("Connection not established!");
		 }
		 catch (SQLException e) {
			 throw new ConnectException("Connection not established!");
		 }
		return conn;
	}

}
