package com.cg.rentalapp.service;

import java.net.ConnectException;
import java.util.List;

import com.cg.rentalapp.dao.AdvertisementDao;
import com.cg.rentalapp.dto.Advertisement;
import com.cg.rentalapp.dto.Agent;
import com.cg.rentalapp.dto.Property;
import com.cg.rentalapp.exception.AdvertisementException;

public class AdvertisementServices implements AdvertisementServicesInterface {
	
	AdvertisementDao advertisements=new AdvertisementDao();
	AdvertisementDao agents=new AdvertisementDao();
	AdvertisementDao properties=new AdvertisementDao();

	public Agent addAgent(Agent agent) throws Exception {
		// TODO Auto-generated method stub
		return agents.saveAgent(agent);
	}

	public Advertisement addAdvertisement(Advertisement ads)  throws Exception{
		// TODO Auto-generated method stub

		return advertisements.saveAdvertisement(ads);
	}

	public List<Advertisement> searchByLocation(String area) throws Exception {
		// TODO Auto-generated method stub
		if(advertisements.findByLocation(area).isEmpty()) {
			throw new AdvertisementException("Advertisements not found!");
		}
		return advertisements.findByLocation(area);
	}

	public List<Advertisement> searchByPincode(long pincode) throws Exception {
		// TODO Auto-generated method stub
		if(advertisements.findByPincode(pincode).isEmpty()) {
			throw new AdvertisementException("Advertisements not found!");
		}
		return advertisements.findByPincode(pincode);
	}

	public Property addProperty(Property property) throws Exception {
		// TODO Auto-generated method stub
		return properties.saveProperty(property);
	}

}
