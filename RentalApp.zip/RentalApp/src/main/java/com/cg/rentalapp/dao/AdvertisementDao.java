package com.cg.rentalapp.dao;

import java.math.BigInteger;
import java.net.ConnectException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.rentalapp.dbutil.DbUtil;
import com.cg.rentalapp.dto.Advertisement;
import com.cg.rentalapp.dto.Agent;
import com.cg.rentalapp.dto.Property;

public class AdvertisementDao implements AdvertisementDaoInterface {
	
	List<Advertisement> advertisements=new ArrayList<Advertisement>(); //creating object for Advertisement list
	List<Agent> agents=new ArrayList<Agent>(); //creating object for Agent list
	List<Property> properties = new ArrayList<Property>(); //creating object for Property list
	
	
	public Agent saveAgent(Agent agent) throws Exception { //for saving agent in database
		Connection conn; 
		conn = DbUtil.getConnection(); //for connection with database
		String query = "insert into agent(name,phone_number) values(?,?)"; //query for inserting data into agent table
		try {
			PreparedStatement psmt = conn.prepareStatement(query); //for getting runtime parameter
			psmt.setString(1,agent.getName());  //fetching name from database
			psmt.setString(2,agent.getPhoneNumber().toString()); //fetching phone number from database
			psmt.executeUpdate(); //for executing the update according to query statements
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Entry already exist");
//			e.printStackTrace();
		}
		agents.add(agent);
		return agent;
	}
	
	public Advertisement saveAdvertisement(Advertisement ads) throws Exception{ //for saving Advertisement in database
		Connection conn =null; //defining connection variable
		conn = DbUtil.getConnection();//for connection with database
		String queryOne = "insert into advertisement(area,pincode,phone_number,flat_type) values(?,?,?,?)";//query for inserting data into Advertisement table
		PreparedStatement psmtOne;
		try {
			psmtOne = conn.prepareStatement(queryOne); //for getting runtime parameter
			psmtOne.setString(1,ads.getArea()); //fetching area from database
			psmtOne.setLong(2,ads.getPincode()); //fetching pincode from database
			psmtOne.setString(3, ads.getPhoneNumber().toString()); //fetching phone number from database
			psmtOne.setString(4,ads.getFlatType()); //fetching flat type from database
			psmtOne.executeUpdate(); //for executing the update according to query statements
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("First be a registered agent");
//			e.printStackTrace();
		}
		
		advertisements.add(ads);
		return ads;
	}
	
	public Property saveProperty(Property property) throws Exception { //for saving Property in database
		// TODO Auto-generated method stub
		Connection conn =null; //defining connection variable
		conn = DbUtil.getConnection();//for connection with database
		String queryFour = "insert into property(area,pincode,building_name,referred_by,commission,flat_type) values(?,?,?,?,?,?)"; //query for inserting data into Property table
		PreparedStatement psmtFour;
		try {
			psmtFour = conn.prepareStatement(queryFour); //for getting runtime parameter
			psmtFour.setString(1,property.getArea()); //fetching area from database
			psmtFour.setLong(2,property.getPincode()); //fetching pincode from database
			psmtFour.setString(3, property.getBuildingName()); //fetching building name from database
			psmtFour.setString(4, property.getReferredBy().toString()); //fetching phone number from database
			psmtFour.setInt(5, property.getCommission()); //fetching commission from database
			psmtFour.setString(6,property.getFlatType()); //fetching flat type from database
			psmtFour.executeUpdate(); //for executing the update according to query statements
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("First be a registered agent");
//			e.printStackTrace();
		}
		properties.add(property);
		return property;
	}
	
	public List<Advertisement> findByLocation(String area) throws Exception { //for fetching advertisements of a specific area from database
		// TODO Auto-generated method stub
		Connection conn =null; //defining connection variable
		ResultSet result = null; //defining ResultSet variable
		conn= DbUtil.getConnection(); //for connection with database
		List<Advertisement> findAdsByArea = new ArrayList<Advertisement>(); //creating object of advertisement list
		String queryTwo = "select * from advertisement where area=?";  //query for fetching advertisements of a specific area from table
		PreparedStatement psmtTwo = null;  //defining PreparedStatement variable
		
		try {
			psmtTwo = conn.prepareStatement(queryTwo); //for getting runtime parameter
			psmtTwo.setString(1, area); //setting value of area in runtime
			result = psmtTwo.executeQuery(); //for executing the query statements
			while(result.next()) {
				String resultInt = result.getString(1); //fetching result from database
				String searchedArea = result.getString(2); //fetching area from database
				long searchedPincode = result.getLong(3);//fetching pin code from database
				long searchedPhoneNumber = result.getLong(4);//fetching phone number from database
				BigInteger reference = BigInteger.valueOf(searchedPhoneNumber);//converting phone number from long to big integer
				String searchedFlatType = result.getString(5);//fetching flat type from database
				List<Advertisement> advertisement = findByLocation(result.getString(1));
				Advertisement ads = new Advertisement(); //creating object of advertisement class
				ads.setArea(resultInt); //setting result in advertisement object
				ads.setArea(searchedArea);//setting area in advertisement object
				ads.setPincode(searchedPincode);//setting pin code in advertisement object
				ads.setPhoneNumber(reference);//setting phone number in advertisement object
				ads.setFlatType(searchedFlatType);//setting flat type in advertisement object
				findAdsByArea.add(ads); // adding searched advertisements in advertisement list
			}
			return findAdsByArea;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Invalid input");
			return null;
		}				
	}
	
	public List<Advertisement> findByPincode(long pincode) throws Exception { //for fetching advertisements through a specific pin code from database
		// TODO Auto-generated method stub
		Connection conn =null;//defining connection variable
		ResultSet result = null;//defining ResultSet variable
		conn= DbUtil.getConnection();//for connection with database
		List<Advertisement> findAdsByPincode = new ArrayList<Advertisement>(); //creating object of advertisement list
		String queryTwo = "select * from advertisement where pincode=?"; //query for fetching advertisements  through a specific pin code from table
		PreparedStatement psmtTwo = null;//defining PreparedStatement variable
		
		try {
			psmtTwo = conn.prepareStatement(queryTwo); //for getting runtime parameter
			psmtTwo.setLong(1, pincode); //setting value of pincode in runtime
			result = psmtTwo.executeQuery(); //for executing the query statements
			while(result.next()) {
				String resultInt = result.getString(1); //fetching result from database
				String searchedArea = result.getString(2); //fetching area from database
				long searchedPincode = result.getLong(3); //fetching pin code from database
				long searchedPhoneNumber = result.getLong(4); //fetching phone number from database
				BigInteger reference = BigInteger.valueOf(searchedPhoneNumber); //converting phone number from long to big integer
				String searchedFlatType = result.getString(5); //fetching flat type from database
				List<Advertisement> advertisement = findByPincode(result.getLong(1));
				Advertisement ads = new Advertisement(); //creating object of advertisement class
				ads.setArea(resultInt); //setting result in advertisement object
				ads.setArea(searchedArea); //setting area in advertisement object
				ads.setPincode(searchedPincode);//setting pin code in advertisement object
				ads.setPhoneNumber(reference); //setting phone number in advertisement object
				ads.setFlatType(searchedFlatType); //setting flat type in advertisement object
				findAdsByPincode.add(ads); // adding searched advertisements in advertisement list
			} 
			return findAdsByPincode;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Invalid input");
			return null;
		}
	}
}
